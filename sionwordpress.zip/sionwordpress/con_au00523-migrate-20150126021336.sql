# WordPress MySQL database migration
# From http://localhost/crossover/AU00523 to http://localhost/crossover/AU00523
#
# Generated: Monday 26. January 2015 02:14 UTC
# Hostname: 192.168.0.4
# Database: `con_au00523`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_comments`
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-01-21 02:08:03', '2015-01-21 02:08:03', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;
#
# End of data contents of table `wp_comments`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_hms_testimonials`
# --------------------------------------------------------


#
# Delete any existing table `wp_hms_testimonials`
#

DROP TABLE IF EXISTS `wp_hms_testimonials`;


#
# Table structure of table `wp_hms_testimonials`
#

CREATE TABLE `wp_hms_testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `image` int(11) NOT NULL DEFAULT '0',
  `testimonial` text NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `readmore` varchar(255) NOT NULL DEFAULT '',
  `testimonial_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `display_order` int(11) NOT NULL DEFAULT '0',
  `display` int(1) NOT NULL DEFAULT '1',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table `wp_hms_testimonials`
#
 
INSERT INTO `wp_hms_testimonials` VALUES (1, 1, 1, 'Brody Kenrick', 0, '<p>Sion has been cleaning our 3 bedroom/2 bathroom house fortnightly for more than a year. We have nothing but great things to say about the experience. The cleaning is always performed expertly and thoroughly and always reliably at the time we\'ve agreed. Sion Cleaning has all their own equipment and supplies which saves many hassles. When we have needed a little extra cleaning or a change in schedule. Sion were happy to receive the extra instructions. We\'ll keep using Sion services into the future.</p>', '', '', '0000-00-00 00:00:00', '2015-01-21 08:04:39', 1, 1) ; 
INSERT INTO `wp_hms_testimonials` VALUES (2, 1, 1, 'Peter and June', 0, '<p>I would like to personally thank you for your care and consideration during the recent cleaning of my sister\'s carpet cleaning. Your attention to detail, project management and workmanship were much appreciated.  I have already recommended your workmanship to several of my friends as we were so happy with the outcome. </p>', '', '', '0000-00-00 00:00:00', '2015-01-21 08:34:12', 2, 1) ;
#
# End of data contents of table `wp_hms_testimonials`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_hms_testimonials_cf`
# --------------------------------------------------------


#
# Delete any existing table `wp_hms_testimonials_cf`
#

DROP TABLE IF EXISTS `wp_hms_testimonials_cf`;


#
# Table structure of table `wp_hms_testimonials_cf`
#

CREATE TABLE `wp_hms_testimonials_cf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `isrequired` int(1) NOT NULL DEFAULT '0',
  `showonform` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table `wp_hms_testimonials_cf`
#

#
# End of data contents of table `wp_hms_testimonials_cf`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_hms_testimonials_cf_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_hms_testimonials_cf_meta`
#

DROP TABLE IF EXISTS `wp_hms_testimonials_cf_meta`;


#
# Table structure of table `wp_hms_testimonials_cf_meta`
#

CREATE TABLE `wp_hms_testimonials_cf_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `testimonial_id` int(11) NOT NULL,
  `key_id` int(11) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `testimonial_id` (`testimonial_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table `wp_hms_testimonials_cf_meta`
#

#
# End of data contents of table `wp_hms_testimonials_cf_meta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_hms_testimonials_group_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_hms_testimonials_group_meta`
#

DROP TABLE IF EXISTS `wp_hms_testimonials_group_meta`;


#
# Table structure of table `wp_hms_testimonials_group_meta`
#

CREATE TABLE `wp_hms_testimonials_group_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `testimonial_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`),
  KEY `testimonial_id` (`testimonial_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table `wp_hms_testimonials_group_meta`
#

#
# End of data contents of table `wp_hms_testimonials_group_meta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_hms_testimonials_groups`
# --------------------------------------------------------


#
# Delete any existing table `wp_hms_testimonials_groups`
#

DROP TABLE IF EXISTS `wp_hms_testimonials_groups`;


#
# Table structure of table `wp_hms_testimonials_groups`
#

CREATE TABLE `wp_hms_testimonials_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table `wp_hms_testimonials_groups`
#

#
# End of data contents of table `wp_hms_testimonials_groups`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_hms_testimonials_templates`
# --------------------------------------------------------


#
# Delete any existing table `wp_hms_testimonials_templates`
#

DROP TABLE IF EXISTS `wp_hms_testimonials_templates`;


#
# Table structure of table `wp_hms_testimonials_templates`
#

CREATE TABLE `wp_hms_testimonials_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 ;

#
# Data contents of table `wp_hms_testimonials_templates`
#
 
INSERT INTO `wp_hms_testimonials_templates` VALUES (1, 1, 'Testimonial, Author, URL, Date', 'a:4:{i:0;s:18:"system_testimonial";i:1;s:13:"system_source";i:2;s:10:"system_url";i:3;s:11:"system_date";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (2, 1, 'Testimonial, URL, Author, Date', 'a:4:{i:0;s:18:"system_testimonial";i:1;s:10:"system_url";i:2;s:13:"system_source";i:3;s:11:"system_date";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (3, 1, 'Author, Testimonial, URL, Date', 'a:4:{i:0;s:13:"system_source";i:1;s:18:"system_testimonial";i:2;s:10:"system_url";i:3;s:11:"system_date";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (4, 1, 'Author, URL, Testimonial, Date', 'a:4:{i:0;s:13:"system_source";i:1;s:10:"system_url";i:2;s:18:"system_testimonial";i:3;s:11:"system_date";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (5, 1, 'URL, Author, Testimonial, Date', 'a:4:{i:0;s:10:"system_url";i:1;s:13:"system_source";i:2;s:18:"system_testimonial";i:3;s:11:"system_date";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (6, 1, 'URL, Testimonial, Author, Date', 'a:4:{i:0;s:10:"system_url";i:1;s:18:"system_testimonial";i:2;s:13:"system_source";i:3;s:11:"system_date";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (7, 1, 'Testimonial, Author, Date, URL', 'a:4:{i:0;s:18:"system_testimonial";i:1;s:13:"system_source";i:2;s:11:"system_date";i:3;s:10:"system_url";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (8, 1, 'Testimonial, URL, Date, Author', 'a:4:{i:0;s:18:"system_testimonial";i:1;s:10:"system_url";i:2;s:11:"system_date";i:3;s:13:"system_source";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (9, 1, 'Testimonial, Date, Author, URL', 'a:4:{i:0;s:18:"system_testimonial";i:1;s:11:"system_date";i:2;s:13:"system_source";i:3;s:10:"system_url";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (10, 1, 'Testimonial, Date, URL, Author', 'a:4:{i:0;s:18:"system_testimonial";i:1;s:11:"system_date";i:2;s:10:"system_url";i:3;s:13:"system_source";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (11, 1, 'Author, Testimonial, Date, URL', 'a:4:{i:0;s:13:"system_source";i:1;s:18:"system_testimonial";i:2;s:11:"system_date";i:3;s:10:"system_url";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (12, 1, 'Author, URL, Date, Testimonial', 'a:4:{i:0;s:13:"system_source";i:1;s:10:"system_url";i:2;s:11:"system_date";i:3;s:18:"system_testimonial";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (13, 1, 'Author, Date, Testimonial, URL', 'a:4:{i:0;s:13:"system_source";i:1;s:11:"system_date";i:2;s:18:"system_testimonial";i:3;s:10:"system_url";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (14, 1, 'Author, Date, URL, Testimonial', 'a:4:{i:0;s:13:"system_source";i:1;s:11:"system_date";i:2;s:10:"system_url";i:3;s:18:"system_testimonial";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (15, 1, 'URL, Author, Date, Testimonial', 'a:4:{i:0;s:10:"system_url";i:1;s:13:"system_source";i:2;s:11:"system_date";i:3;s:18:"system_testimonial";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (16, 1, 'URL, Testimonial, Date, Author', 'a:4:{i:0;s:10:"system_url";i:1;s:18:"system_testimonial";i:2;s:11:"system_date";i:3;s:13:"system_source";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (17, 1, 'URL, Date, Author, Testimonial', 'a:4:{i:0;s:10:"system_url";i:1;s:11:"system_date";i:2;s:13:"system_source";i:3;s:18:"system_testimonial";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (18, 1, 'URL, Date, Testimonial, Author', 'a:4:{i:0;s:10:"system_url";i:1;s:11:"system_date";i:2;s:18:"system_testimonial";i:3;s:13:"system_source";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (19, 1, 'Date, Testimonial, Author, URL', 'a:4:{i:0;s:11:"system_date";i:1;s:18:"system_testimonial";i:2;s:13:"system_source";i:3;s:10:"system_url";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (20, 1, 'Date, Testimonial, URL, Author', 'a:4:{i:0;s:11:"system_date";i:1;s:18:"system_testimonial";i:2;s:10:"system_url";i:3;s:13:"system_source";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (21, 1, 'Date, Author, Testimonial, URL', 'a:4:{i:0;s:11:"system_date";i:1;s:13:"system_source";i:2;s:18:"system_testimonial";i:3;s:10:"system_url";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (22, 1, 'Date, Author, URL, Testimonial', 'a:4:{i:0;s:11:"system_date";i:1;s:13:"system_source";i:2;s:10:"system_url";i:3;s:18:"system_testimonial";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (23, 1, 'Date, URL, Author, Testimonial', 'a:4:{i:0;s:11:"system_date";i:1;s:10:"system_url";i:2;s:13:"system_source";i:3;s:18:"system_testimonial";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (24, 1, 'Date, URL, Testimonial, Author', 'a:4:{i:0;s:11:"system_date";i:1;s:10:"system_url";i:2;s:18:"system_testimonial";i:3;s:13:"system_source";}') ; 
INSERT INTO `wp_hms_testimonials_templates` VALUES (25, 1, 'Custome', 'a:2:{i:0;s:18:"system_testimonial";i:1;s:13:"system_source";}') ;
#
# End of data contents of table `wp_hms_testimonials_templates`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_options`
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/crossover/AU00523', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'home', 'http://localhost/crossover/AU00523', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogname', 'Sion Cleaning Services Pty Ltd', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'admin_email', 'ashokchand@crossovernepal.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'permalink_structure', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (33, 'active_plugins', 'a:4:{i:0;s:36:"contact-form-7/wp-contact-form-7.php";i:1;s:37:"hms-testimonials/hms-testimonials.php";i:2;s:37:"tinymce-advanced/tinymce-advanced.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'sion', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'sion', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '30133', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '30133', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:12:"home_sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"about_sidebar";N;s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'cron', 'a:5:{i:1422241771;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1422243362;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1422255780;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1422281357;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, '_transient_random_seed', '75d819d5645c52f18682ec194b7754e3', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-4.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-4.1.zip";s:10:"no_content";s:68:"https://downloads.wordpress.org/release/wordpress-4.1-no-content.zip";s:11:"new_bundled";s:69:"https://downloads.wordpress.org/release/wordpress-4.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.1";s:7:"version";s:3:"4.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1422238202;s:15:"version_checked";s:3:"4.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1422238251;s:7:"checked";a:1:{s:4:"sion";s:0:"";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, '_site_transient_timeout_browser_c917cbcbdbc2b619466b4aeb270ad980', '1422410969', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, '_site_transient_browser_c917cbcbdbc2b619466b4aeb270ad980', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"36.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (109, '_transient_twentyfifteen_categories', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (122, '_transient_timeout_plugin_slugs', '1421989992', 'no') ; 
INSERT INTO `wp_options` VALUES (123, '_transient_plugin_slugs', 'a:4:{i:0;s:36:"contact-form-7/wp-contact-form-7.php";i:1;s:37:"hms-testimonials/hms-testimonials.php";i:2;s:37:"tinymce-advanced/tinymce-advanced.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (129, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1421809829;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (130, 'current_theme', 'Sion', 'yes') ; 
INSERT INTO `wp_options` VALUES (131, 'theme_mods_sion', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:9:"main-menu";i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (132, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (133, 'of_template', 'a:18:{i:0;a:2:{s:4:"name";s:6:"Header";s:4:"type";s:7:"heading";}i:1;a:5:{s:4:"name";s:17:"Logo Image Upload";s:4:"desc";s:35:"This is an Logo image upload field.";s:2:"id";s:16:"sion_header_logo";s:3:"std";s:0:"";s:4:"type";s:6:"upload";}i:2;a:5:{s:4:"name";s:20:"Favicon Image Upload";s:4:"desc";s:38:"This is an Favicon image upload field.";s:2:"id";s:12:"sion_favicon";s:3:"std";s:0:"";s:4:"type";s:6:"upload";}i:3;a:2:{s:4:"name";s:19:"Contact Information";s:4:"type";s:7:"heading";}i:4;a:5:{s:4:"name";s:30:"Sion Cleaning Services Pty Ltd";s:4:"desc";s:31:"Sion Cleaning Services Pty Ltd.";s:2:"id";s:9:"sion_sion";s:3:"std";s:0:"";s:4:"type";s:8:"textarea";}i:5;a:5:{s:4:"name";s:11:"Office Name";s:4:"desc";s:22:"This is a Office Name.";s:2:"id";s:10:"sion_oname";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:6;a:5:{s:4:"name";s:14:"Office Address";s:4:"desc";s:25:"This is a Office Address.";s:2:"id";s:13:"sion_oaddress";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:7;a:5:{s:4:"name";s:15:"Contact Numbers";s:4:"desc";s:25:"This is a Contact Number.";s:2:"id";s:12:"sion_pnumber";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:8;a:5:{s:4:"name";s:0:"";s:4:"desc";s:25:"This is a Contact Number.";s:2:"id";s:13:"sion_pnumber1";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:9;a:5:{s:4:"name";s:13:"Email Address";s:4:"desc";s:16:"This is a Email.";s:2:"id";s:10:"sion_email";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:10;a:5:{s:4:"name";s:10:"Google Map";s:4:"desc";s:21:"This is a Google Map.";s:2:"id";s:14:"sion_googlemap";s:3:"std";s:0:"";s:4:"type";s:8:"textarea";}i:11;a:2:{s:4:"name";s:22:"Get Connected With Us ";s:4:"type";s:7:"heading";}i:12;a:5:{s:4:"name";s:13:"Facebook Link";s:4:"desc";s:24:"This is a Facebook link.";s:2:"id";s:13:"sion_facebook";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:13;a:5:{s:4:"name";s:12:"Google+ Link";s:4:"desc";s:23:"This is a Google+ link.";s:2:"id";s:11:"sion_google";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:14;a:5:{s:4:"name";s:12:"Youtube Link";s:4:"desc";s:23:"This is a Youtube link.";s:2:"id";s:12:"sion_youtube";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:15;a:5:{s:4:"name";s:12:"Twitter Link";s:4:"desc";s:23:"This is a Twitter link.";s:2:"id";s:12:"sion_twitter";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:16;a:2:{s:4:"name";s:18:"Copy Right Content";s:4:"type";s:7:"heading";}i:17;a:5:{s:4:"name";s:15:"Copy Right Text";s:4:"desc";s:26:"This is a Copy Right Text.";s:2:"id";s:14:"sion_copyright";s:3:"std";s:0:"";s:4:"type";s:4:"text";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (134, 'of_themename', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (135, 'of_shortname', 'sion', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (148, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (157, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1421832234', 'yes') ; 
INSERT INTO `wp_options` VALUES (158, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4912";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"3077";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"3020";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2528";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2344";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1894";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1729";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1679";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1674";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1674";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1611";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1610";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1505";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1320";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1274";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1171";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1169";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1083";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1078";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"914";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"903";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"874";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"842";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"835";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"790";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"757";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"748";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"708";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:3:"697";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"692";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"681";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"657";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"649";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"642";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"641";}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";s:3:"621";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"620";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"604";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"599";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"593";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (159, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (160, 'tadv_version', '3420', 'yes') ; 
INSERT INTO `wp_options` VALUES (161, 'tadv_plugins', 'a:6:{i:0;s:5:"style";i:1;s:8:"emotions";i:2;s:5:"print";i:3;s:13:"searchreplace";i:4;s:10:"xhtmlxtras";i:5;s:8:"advimage";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (162, 'tadv_options', 'a:7:{s:8:"advlink1";i:0;s:8:"advimage";i:1;s:11:"editorstyle";i:0;s:11:"hideclasses";i:0;s:11:"contextmenu";i:0;s:8:"no_autop";i:1;s:7:"advlist";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (163, 'tadv_toolbars', 'a:4:{s:9:"toolbar_1";a:20:{i:0;s:4:"bold";i:1;s:6:"italic";i:2;s:13:"strikethrough";i:3;s:9:"underline";i:4;s:7:"bullist";i:5;s:7:"numlist";i:6;s:7:"outdent";i:7;s:6:"indent";i:8;s:11:"justifyleft";i:9;s:13:"justifycenter";i:10;s:12:"justifyright";i:11;s:4:"link";i:12;s:6:"unlink";i:13;s:5:"image";i:14;s:10:"styleprops";i:15;s:7:"wp_more";i:16;s:7:"wp_page";i:17;s:12:"spellchecker";i:18;s:6:"search";i:19;s:10:"fullscreen";}s:9:"toolbar_2";a:17:{i:0;s:14:"fontsizeselect";i:1;s:12:"formatselect";i:2;s:9:"pastetext";i:3;s:9:"pasteword";i:4;s:12:"removeformat";i:5;s:7:"charmap";i:6;s:5:"print";i:7;s:9:"forecolor";i:8;s:9:"backcolor";i:9;s:8:"emotions";i:10;s:3:"sup";i:11;s:3:"sub";i:12;s:5:"media";i:13;s:4:"undo";i:14;s:4:"redo";i:15;s:7:"attribs";i:16;s:7:"wp_help";}s:9:"toolbar_3";a:0:{}s:9:"toolbar_4";a:0:{}}', 'no') ; 
INSERT INTO `wp_options` VALUES (164, 'tadv_btns1', 'a:20:{i:0;s:4:"bold";i:1;s:6:"italic";i:2;s:13:"strikethrough";i:3;s:9:"underline";i:4;s:7:"bullist";i:5;s:7:"numlist";i:6;s:7:"outdent";i:7;s:6:"indent";i:8;s:11:"justifyleft";i:9;s:13:"justifycenter";i:10;s:12:"justifyright";i:11;s:4:"link";i:12;s:6:"unlink";i:13;s:5:"image";i:14;s:10:"styleprops";i:15;s:7:"wp_more";i:16;s:7:"wp_page";i:17;s:12:"spellchecker";i:18;s:6:"search";i:19;s:10:"fullscreen";}', 'no') ; 
INSERT INTO `wp_options` VALUES (165, 'tadv_btns2', 'a:17:{i:0;s:14:"fontsizeselect";i:1;s:12:"formatselect";i:2;s:9:"pastetext";i:3;s:9:"pasteword";i:4;s:12:"removeformat";i:5;s:7:"charmap";i:6;s:5:"print";i:7;s:9:"forecolor";i:8;s:9:"backcolor";i:9;s:8:"emotions";i:10;s:3:"sup";i:11;s:3:"sub";i:12;s:5:"media";i:13;s:4:"undo";i:14;s:4:"redo";i:15;s:7:"attribs";i:16;s:7:"wp_help";}', 'no') ; 
INSERT INTO `wp_options` VALUES (166, 'tadv_btns3', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (167, 'tadv_btns4', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (168, 'tadv_allbtns', 'a:66:{i:0;s:2:"hr";i:1;s:6:"wp_adv";i:2;s:10:"blockquote";i:3;s:4:"bold";i:4;s:6:"italic";i:5;s:13:"strikethrough";i:6;s:9:"underline";i:7;s:7:"bullist";i:8;s:7:"numlist";i:9;s:7:"outdent";i:10;s:6:"indent";i:11;s:11:"justifyleft";i:12;s:13:"justifycenter";i:13;s:12:"justifyright";i:14;s:11:"justifyfull";i:15;s:3:"cut";i:16;s:4:"copy";i:17;s:5:"paste";i:18;s:4:"link";i:19;s:6:"unlink";i:20;s:5:"image";i:21;s:7:"wp_more";i:22;s:7:"wp_page";i:23;s:6:"search";i:24;s:7:"replace";i:25;s:10:"fontselect";i:26;s:14:"fontsizeselect";i:27;s:7:"wp_help";i:28;s:10:"fullscreen";i:29;s:11:"styleselect";i:30;s:12:"formatselect";i:31;s:9:"forecolor";i:32;s:9:"backcolor";i:33;s:9:"pastetext";i:34;s:9:"pasteword";i:35;s:12:"removeformat";i:36;s:7:"cleanup";i:37;s:12:"spellchecker";i:38;s:7:"charmap";i:39;s:5:"print";i:40;s:4:"undo";i:41;s:4:"redo";i:42;s:13:"tablecontrols";i:43;s:4:"cite";i:44;s:3:"ins";i:45;s:3:"del";i:46;s:4:"abbr";i:47;s:7:"acronym";i:48;s:7:"attribs";i:49;s:5:"layer";i:50;s:5:"advhr";i:51;s:4:"code";i:52;s:11:"visualchars";i:53;s:11:"nonbreaking";i:54;s:3:"sub";i:55;s:3:"sup";i:56;s:9:"visualaid";i:57;s:10:"insertdate";i:58;s:10:"inserttime";i:59;s:6:"anchor";i:60;s:10:"styleprops";i:61;s:8:"emotions";i:62;s:5:"media";i:63;s:7:"iespell";i:64;s:9:"separator";i:65;s:1:"|";}', 'no') ; 
INSERT INTO `wp_options` VALUES (178, 'hms_testimonials_db_version', '13', 'yes') ; 
INSERT INTO `wp_options` VALUES (179, 'hms_testimonials', 'a:19:{s:4:"role";s:13:"administrator";s:11:"autoapprove";s:13:"administrator";s:9:"moderator";s:13:"administrator";s:13:"resetapproval";i:1;s:20:"num_users_can_create";i:1;s:17:"show_active_links";i:0;s:21:"active_links_nofollow";i:1;s:30:"moderators_can_access_settings";i:1;s:9:"collation";s:17:"latin1_swedish_ci";s:13:"use_recaptcha";i:0;s:20:"recaptcha_privatekey";s:0:"";s:19:"recaptcha_publickey";s:0:"";s:11:"image_width";i:100;s:12:"image_height";i:100;s:7:"js_load";i:0;s:20:"testimonial_contaner";s:10:"blockquote";s:11:"flood_limit";i:5;s:13:"form_show_url";i:1;s:16:"form_show_upload";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (184, 'sion_header_logo', 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/logo.png', 'yes') ; 
INSERT INTO `wp_options` VALUES (185, 'sion_favicon', 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/favicon.ico', 'yes') ; 
INSERT INTO `wp_options` VALUES (186, 'sion_oname', 'Sion Cleaning Services Pty Ltd.', 'yes') ; 
INSERT INTO `wp_options` VALUES (187, 'sion_oaddress', 'Surry Hills NSW 2010 <br> Australia', 'yes') ; 
INSERT INTO `wp_options` VALUES (188, 'sion_pnumber', '0416 060 122', 'yes') ; 
INSERT INTO `wp_options` VALUES (189, 'sion_pnumber1', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (190, 'sion_email', 'sioncleaningservices@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (191, 'sion_googlemap', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13248.8000354112!2d151.20984479999998!3d-33.884502399999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12ae21f935bc5b%3A0x5017d681632cc90!2sSurry+Hills+NSW+2010%2C+Australia!5e0!3m2!1sen!2snp!4v1421901919268" width="100%" height="300" frameborder="0" style="border:0"></iframe>', 'yes') ; 
INSERT INTO `wp_options` VALUES (192, 'sion_facebook', 'https://www.facebook.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (193, 'sion_google', 'https://www.google.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (194, 'sion_youtube', 'https://www.youtube.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'sion_twitter', 'https://www.twitter.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'sion_copyright', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (197, 'wpcf7', 'a:1:{s:7:"version";s:3:"3.6";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (238, 'sion_sion', 'We are always looking to improve our site and the way that we serve you. If you have any general comments or wish to provide us with some feedback about your experience on our website, take a moment and complete our customer survey. Your answers to these questions could help shape the future direction of Sion Cleaning Services.', 'yes') ; 
INSERT INTO `wp_options` VALUES (258, 'auto_updater.lock', '1422237230', 'no') ; 
INSERT INTO `wp_options` VALUES (259, '_site_transient_timeout_theme_roots', '1422239054', 'yes') ; 
INSERT INTO `wp_options` VALUES (260, '_site_transient_theme_roots', 'a:1:{s:4:"sion";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (261, '_site_transient_update_plugins', 'O:8:"stdClass":1:{s:12:"last_checked";i:1422238440;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (262, '_transient_doing_cron', '1422238202.1789700984954833984375', 'yes') ;
#
# End of data contents of table `wp_options`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_postmeta`
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 2, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (3, 2, '_wp_trash_meta_time', '1421811355') ; 
INSERT INTO `wp_postmeta` VALUES (4, 5, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 5, '_edit_lock', '1421811343:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 5, '_wp_page_template', 'home.php') ; 
INSERT INTO `wp_postmeta` VALUES (7, 7, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (8, 7, '_edit_lock', '1421822251:1') ; 
INSERT INTO `wp_postmeta` VALUES (9, 7, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (10, 9, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (11, 9, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (12, 9, '_menu_item_object_id', '7') ; 
INSERT INTO `wp_postmeta` VALUES (13, 9, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (14, 9, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (15, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (16, 9, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (17, 9, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (19, 10, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (20, 10, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (21, 10, '_menu_item_object_id', '5') ; 
INSERT INTO `wp_postmeta` VALUES (22, 10, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (23, 10, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (24, 10, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (25, 10, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (26, 10, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (28, 11, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (29, 11, '_edit_lock', '1421815720:1') ; 
INSERT INTO `wp_postmeta` VALUES (30, 12, '_wp_attached_file', '2015/01/banner-1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (31, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1349;s:6:"height";i:449;s:4:"file";s:20:"2015/01/banner-1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"banner-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"banner-1-300x100.jpg";s:5:"width";i:300;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"banner-1-1024x341.jpg";s:5:"width";i:1024;s:6:"height";i:341;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (32, 13, '_wp_attached_file', '2015/01/banner-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (33, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1349;s:6:"height";i:449;s:4:"file";s:20:"2015/01/banner-2.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"banner-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"banner-2-300x100.jpg";s:5:"width";i:300;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"banner-2-1024x341.jpg";s:5:"width";i:1024;s:6:"height";i:341;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (34, 14, '_wp_attached_file', '2015/01/banner-3.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (35, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1349;s:6:"height";i:449;s:4:"file";s:20:"2015/01/banner-3.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"banner-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"banner-3-300x100.jpg";s:5:"width";i:300;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"banner-3-1024x341.jpg";s:5:"width";i:1024;s:6:"height";i:341;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (36, 15, '_wp_attached_file', '2015/01/banner-4.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (37, 15, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1349;s:6:"height";i:449;s:4:"file";s:20:"2015/01/banner-4.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"banner-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"banner-4-300x100.jpg";s:5:"width";i:300;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"banner-4-1024x341.jpg";s:5:"width";i:1024;s:6:"height";i:341;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (38, 11, '_thumbnail_id', '15') ; 
INSERT INTO `wp_postmeta` VALUES (39, 16, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (40, 16, '_edit_lock', '1421815909:1') ; 
INSERT INTO `wp_postmeta` VALUES (41, 16, '_thumbnail_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (42, 17, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (43, 17, '_edit_lock', '1421816044:1') ; 
INSERT INTO `wp_postmeta` VALUES (44, 17, '_thumbnail_id', '13') ; 
INSERT INTO `wp_postmeta` VALUES (45, 18, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (46, 18, '_edit_lock', '1421816395:1') ; 
INSERT INTO `wp_postmeta` VALUES (47, 18, '_thumbnail_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (48, 1, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (49, 1, '_wp_trash_meta_time', '1421816549') ; 
INSERT INTO `wp_postmeta` VALUES (50, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}') ; 
INSERT INTO `wp_postmeta` VALUES (51, 20, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (52, 20, '_edit_lock', '1421816462:1') ; 
INSERT INTO `wp_postmeta` VALUES (53, 20, '_wp_page_template', 'template-gallery.php') ; 
INSERT INTO `wp_postmeta` VALUES (54, 22, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (55, 22, '_edit_lock', '1421816500:1') ; 
INSERT INTO `wp_postmeta` VALUES (56, 22, '_wp_page_template', 'template-contact.php') ; 
INSERT INTO `wp_postmeta` VALUES (57, 24, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (58, 24, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (59, 24, '_menu_item_object_id', '22') ; 
INSERT INTO `wp_postmeta` VALUES (60, 24, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (61, 24, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (62, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (63, 24, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (64, 24, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (75, 26, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (76, 26, '_edit_lock', '1421817319:1') ; 
INSERT INTO `wp_postmeta` VALUES (79, 28, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (82, 28, '_edit_lock', '1421817114:1') ; 
INSERT INTO `wp_postmeta` VALUES (83, 30, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (84, 30, '_edit_lock', '1421818032:1') ; 
INSERT INTO `wp_postmeta` VALUES (95, 36, '_wp_attached_file', '2015/01/welcome.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (96, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:357;s:6:"height";i:309;s:4:"file";s:19:"2015/01/welcome.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"welcome-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"welcome-300x260.jpg";s:5:"width";i:300;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (97, 7, '_thumbnail_id', '36') ; 
INSERT INTO `wp_postmeta` VALUES (98, 44, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (99, 44, '_edit_lock', '1421822636:1') ; 
INSERT INTO `wp_postmeta` VALUES (100, 45, '_wp_attached_file', '2015/01/domestic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (101, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:20:"2015/01/domestic.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"domestic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"domestic-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (102, 44, '_thumbnail_id', '45') ; 
INSERT INTO `wp_postmeta` VALUES (103, 46, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (104, 46, '_edit_lock', '1421822961:1') ; 
INSERT INTO `wp_postmeta` VALUES (105, 47, '_wp_attached_file', '2015/01/commercial.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (106, 47, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:22:"2015/01/commercial.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"commercial-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"commercial-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (107, 46, '_thumbnail_id', '47') ; 
INSERT INTO `wp_postmeta` VALUES (108, 48, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (109, 48, '_edit_lock', '1421826024:1') ; 
INSERT INTO `wp_postmeta` VALUES (110, 49, '_wp_attached_file', '2015/01/carpet.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (111, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:18:"2015/01/carpet.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"carpet-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"carpet-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (112, 48, '_thumbnail_id', '49') ; 
INSERT INTO `wp_postmeta` VALUES (113, 50, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (114, 50, '_edit_lock', '1421826172:1') ; 
INSERT INTO `wp_postmeta` VALUES (115, 51, '_wp_attached_file', '2015/01/window.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (116, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:18:"2015/01/window.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"window-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"window-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (117, 50, '_thumbnail_id', '51') ; 
INSERT INTO `wp_postmeta` VALUES (118, 52, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (119, 52, '_edit_lock', '1421826263:1') ; 
INSERT INTO `wp_postmeta` VALUES (120, 53, '_wp_attached_file', '2015/01/spring.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (121, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:18:"2015/01/spring.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"spring-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"spring-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (122, 52, '_thumbnail_id', '53') ; 
INSERT INTO `wp_postmeta` VALUES (123, 54, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (124, 54, '_edit_lock', '1421826989:1') ; 
INSERT INTO `wp_postmeta` VALUES (125, 55, '_wp_attached_file', '2015/01/waterpressure.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (126, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:25:"2015/01/waterpressure.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"waterpressure-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"waterpressure-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (127, 54, '_thumbnail_id', '55') ; 
INSERT INTO `wp_postmeta` VALUES (128, 56, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (129, 56, '_edit_lock', '1421829213:1') ; 
INSERT INTO `wp_postmeta` VALUES (130, 57, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (131, 57, '_edit_lock', '1421829231:1') ; 
INSERT INTO `wp_postmeta` VALUES (132, 58, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (133, 58, '_edit_lock', '1421829247:1') ; 
INSERT INTO `wp_postmeta` VALUES (134, 59, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (135, 59, '_edit_lock', '1421829263:1') ; 
INSERT INTO `wp_postmeta` VALUES (136, 60, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (137, 60, '_edit_lock', '1421829277:1') ; 
INSERT INTO `wp_postmeta` VALUES (138, 61, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (139, 61, '_edit_lock', '1421829477:1') ; 
INSERT INTO `wp_postmeta` VALUES (140, 62, '_form', '[response]\n<ul> <li><label>Name:</label>  [text* your-name] </li>\n<li><label>Email:</label> [email* your-email] </li>\n<li><label>Phone:</label> [text* Phone] </li>\n<li><label>Message:</label> [textarea message 40x4]</li>\n <li><label>&nbsp;</label> [submit class:submit "Submit"]</li></ul>') ; 
INSERT INTO `wp_postmeta` VALUES (141, 62, '_mail', 'a:7:{s:7:"subject";s:0:"";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:71:"From: [your-name] <[your-email]>\n\nMessage Body:\nPhone:[Phone]\n[message]";s:9:"recipient";s:29:"ashokchand@crossovernepal.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (142, 62, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:144:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on Sion Cleaning Services Pty Ltd (http://localhost/crossover/AU00523)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (143, 62, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (144, 62, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (145, 62, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (146, 63, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (147, 63, '_edit_lock', '1421894541:1') ; 
INSERT INTO `wp_postmeta` VALUES (148, 64, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (149, 64, '_edit_lock', '1421896200:1') ; 
INSERT INTO `wp_postmeta` VALUES (150, 65, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (151, 65, '_edit_lock', '1421896222:1') ; 
INSERT INTO `wp_postmeta` VALUES (152, 66, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (153, 66, '_edit_lock', '1421896243:1') ; 
INSERT INTO `wp_postmeta` VALUES (154, 67, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (155, 67, '_edit_lock', '1421896272:1') ; 
INSERT INTO `wp_postmeta` VALUES (156, 68, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (157, 68, '_edit_lock', '1421897248:1') ; 
INSERT INTO `wp_postmeta` VALUES (158, 69, '_form', '[response]\n<table>\n<tr>\n<td class="l">Name (<span>*</span>)</td>\n<td class="r">[text* your-name]</td>\n</tr>\n<tr>\n<td class="l">Email (<span>*</span>)</td>\n   <td class="r"> [email* your-email] </td>\n</tr>\n<tr>\n<td class="l">Phone(<span>*</span>)</td>\n    <td class="r"> [tel* YourPhone]</td>\n</tr>\n<tr>\n<td class="l">Subject</td>\n   <td class="r"> [text your-subject] </td>\n</tr>\n<tr>\n<td class="l">Message</td>\n   <td class="r"> [textarea your-message] </td>\n</tr>\n<tr>\n<td class="l"></td>\n<td class="r">[submit "Send"]</td>\n</tr>\n</table>') ; 
INSERT INTO `wp_postmeta` VALUES (159, 69, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:97:"From: [your-name] <[your-email]>[YourPhone]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]";s:9:"recipient";s:29:"ashokchand@crossovernepal.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (160, 69, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:144:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on Sion Cleaning Services Pty Ltd (http://localhost/crossover/AU00523)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (161, 69, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (162, 69, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (163, 69, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (164, 70, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (165, 70, '_edit_lock', '1421912918:1') ; 
INSERT INTO `wp_postmeta` VALUES (166, 71, '_wp_attached_file', '2015/01/g1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (167, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2015/01/g1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"g1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"g1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (168, 72, '_wp_attached_file', '2015/01/g2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (169, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2015/01/g2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"g2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"g2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (170, 73, '_wp_attached_file', '2015/01/g3.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (171, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2015/01/g3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"g3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"g3-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (172, 74, '_wp_attached_file', '2015/01/g4.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (173, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2015/01/g4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"g4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"g4-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (174, 75, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (175, 75, '_edit_lock', '1421912970:1') ; 
INSERT INTO `wp_postmeta` VALUES (176, 76, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (177, 76, '_edit_lock', '1421913006:1') ; 
INSERT INTO `wp_postmeta` VALUES (178, 77, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (179, 77, '_edit_lock', '1421913937:1') ; 
INSERT INTO `wp_postmeta` VALUES (180, 78, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (181, 78, '_edit_lock', '1421915785:1') ; 
INSERT INTO `wp_postmeta` VALUES (182, 78, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (183, 80, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (184, 80, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (185, 80, '_menu_item_object_id', '78') ; 
INSERT INTO `wp_postmeta` VALUES (186, 80, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (187, 80, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (188, 80, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (189, 80, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (190, 80, '_menu_item_url', '') ;
#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_posts`
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2015-01-21 02:08:03', '2015-01-21 02:08:03', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world', '', '', '2015-01-21 05:02:29', '2015-01-21 05:02:29', '', 0, 'http://localhost/crossover/AU00523/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2015-01-21 02:08:03', '2015-01-21 02:08:03', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/crossover/AU00523/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2015-01-21 03:35:55', '2015-01-21 03:35:55', '', 0, 'http://localhost/crossover/AU00523/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (3, 1, '2015-01-21 02:09:30', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-01-21 02:09:30', '0000-00-00 00:00:00', '', 0, 'http://localhost/crossover/AU00523/?p=3', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2015-01-21 03:35:55', '2015-01-21 03:35:55', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/crossover/AU00523/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-01-21 03:35:55', '2015-01-21 03:35:55', '', 2, 'http://localhost/crossover/AU00523/?p=4', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2015-01-21 03:37:58', '2015-01-21 03:37:58', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2015-01-21 03:37:58', '2015-01-21 03:37:58', '', 0, 'http://localhost/crossover/AU00523/?page_id=5', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2015-01-21 03:37:58', '2015-01-21 03:37:58', '', 'Home', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2015-01-21 03:37:58', '2015-01-21 03:37:58', '', 5, 'http://localhost/crossover/AU00523/?p=6', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2015-01-21 03:38:35', '2015-01-21 03:38:35', '<p>Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p>', 'About Us', '', 'publish', 'open', 'open', '', 'about-us', '', '', '2015-01-21 06:35:00', '2015-01-21 06:35:00', '', 0, 'http://localhost/crossover/AU00523/?page_id=7', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2015-01-21 03:38:35', '2015-01-21 03:38:35', 'df df', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 03:38:35', '2015-01-21 03:38:35', '', 7, 'http://localhost/crossover/AU00523/?p=8', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2015-01-21 03:39:48', '2015-01-21 03:39:48', ' ', '', '', 'publish', 'open', 'open', '', '9', '', '', '2015-01-22 08:09:46', '2015-01-22 08:09:46', '', 0, 'http://localhost/crossover/AU00523/?p=9', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2015-01-21 03:39:48', '2015-01-21 03:39:48', ' ', '', '', 'publish', 'open', 'open', '', '10', '', '', '2015-01-22 08:09:46', '2015-01-22 08:09:46', '', 0, 'http://localhost/crossover/AU00523/?p=10', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2015-01-21 04:50:26', '2015-01-21 04:50:26', '', 'Banner first', '', 'publish', 'closed', 'closed', '', 'banner-first', '', '', '2015-01-21 04:50:26', '2015-01-21 04:50:26', '', 0, 'http://localhost/crossover/AU00523/?post_type=banner&#038;p=11', 0, 'banner', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2015-01-21 04:50:02', '2015-01-21 04:50:02', '', 'banner-1', '', 'inherit', 'open', 'open', '', 'banner-1', '', '', '2015-01-21 04:50:02', '2015-01-21 04:50:02', '', 11, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/banner-1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2015-01-21 04:50:05', '2015-01-21 04:50:05', '', 'banner-2', '', 'inherit', 'open', 'open', '', 'banner-2', '', '', '2015-01-21 04:50:05', '2015-01-21 04:50:05', '', 11, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/banner-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2015-01-21 04:50:07', '2015-01-21 04:50:07', '', 'banner-3', '', 'inherit', 'open', 'open', '', 'banner-3', '', '', '2015-01-21 04:50:07', '2015-01-21 04:50:07', '', 11, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/banner-3.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2015-01-21 04:50:09', '2015-01-21 04:50:09', '', 'banner-4', '', 'inherit', 'open', 'open', '', 'banner-4', '', '', '2015-01-21 04:50:09', '2015-01-21 04:50:09', '', 11, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/banner-4.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2015-01-21 04:52:18', '2015-01-21 04:52:18', '', 'Banner second', '', 'publish', 'closed', 'closed', '', 'banner-second', '', '', '2015-01-21 04:52:18', '2015-01-21 04:52:18', '', 0, 'http://localhost/crossover/AU00523/?post_type=banner&#038;p=16', 0, 'banner', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2015-01-21 04:55:09', '2015-01-21 04:55:09', '', 'Banner Third', '', 'publish', 'closed', 'closed', '', 'banner-third', '', '', '2015-01-21 04:55:09', '2015-01-21 04:55:09', '', 0, 'http://localhost/crossover/AU00523/?post_type=banner&#038;p=17', 0, 'banner', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2015-01-21 04:57:07', '2015-01-21 04:57:07', '', 'Banner fourth', '', 'publish', 'closed', 'closed', '', 'banner-fourth', '', '', '2015-01-21 04:57:07', '2015-01-21 04:57:07', '', 0, 'http://localhost/crossover/AU00523/?post_type=banner&#038;p=18', 0, 'banner', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2015-01-21 05:02:29', '2015-01-21 05:02:29', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2015-01-21 05:02:29', '2015-01-21 05:02:29', '', 1, 'http://localhost/crossover/AU00523/?p=19', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2015-01-21 05:03:19', '2015-01-21 05:03:19', '', 'Gallery', '', 'publish', 'open', 'open', '', 'gallery', '', '', '2015-01-21 05:03:19', '2015-01-21 05:03:19', '', 0, 'http://localhost/crossover/AU00523/?page_id=20', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2015-01-21 05:03:19', '2015-01-21 05:03:19', '', 'Gallery', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2015-01-21 05:03:19', '2015-01-21 05:03:19', '', 20, 'http://localhost/crossover/AU00523/?p=21', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2015-01-21 05:03:40', '2015-01-21 05:03:40', '', 'Contact us', '', 'publish', 'open', 'open', '', 'contact-us', '', '', '2015-01-21 05:03:40', '2015-01-21 05:03:40', '', 0, 'http://localhost/crossover/AU00523/?page_id=22', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2015-01-21 05:03:40', '2015-01-21 05:03:40', '', 'Contact us', '', 'inherit', 'open', 'open', '', '22-revision-v1', '', '', '2015-01-21 05:03:40', '2015-01-21 05:03:40', '', 22, 'http://localhost/crossover/AU00523/?p=23', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2015-01-21 05:05:26', '2015-01-21 05:05:26', ' ', '', '', 'publish', 'open', 'open', '', '24', '', '', '2015-01-22 08:09:46', '2015-01-22 08:09:46', '', 0, 'http://localhost/crossover/AU00523/?p=24', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2015-01-21 05:07:46', '2015-01-21 05:07:46', 'Our Mission is to provide efficient cleaning services with the highest quality and responsibility to satisfy all needs of our clients.', 'Our Mission', '', 'publish', 'open', 'open', '', 'our-mission', '', '', '2015-01-21 05:15:52', '2015-01-21 05:15:52', '', 0, 'http://localhost/crossover/AU00523/?p=26', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2015-01-21 05:07:46', '2015-01-21 05:07:46', 'Our Mission is to provide efficient cleaning services with the highest quality and responsibility to satisfy all needs of our clients.', 'Our mission', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2015-01-21 05:07:46', '2015-01-21 05:07:46', '', 26, 'http://localhost/crossover/AU00523/?p=27', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2015-01-21 05:08:40', '2015-01-21 05:08:40', 'Our Vision is to be recognized as the leader in providing cleaning services in Australia, always generated confidence in our customers.', 'Our Vision', '', 'publish', 'open', 'open', '', 'our-vision', '', '', '2015-01-21 05:12:57', '2015-01-21 05:12:57', '', 0, 'http://localhost/crossover/AU00523/?p=28', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2015-01-21 05:08:40', '2015-01-21 05:08:40', 'Our Vision is to be recognized as the leader in providing cleaning services in Australia, always generated confidence in our customers.', 'Our vision', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2015-01-21 05:08:40', '2015-01-21 05:08:40', '', 28, 'http://localhost/crossover/AU00523/?p=29', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2015-01-21 05:09:18', '2015-01-21 05:09:18', 'We are a well established, reliable and committed cleaning company that have been providing an exceptional and diligent service to our clients.', 'Why Us?', '', 'publish', 'open', 'open', '', 'why-us', '', '', '2015-01-21 05:26:22', '2015-01-21 05:26:22', '', 0, 'http://localhost/crossover/AU00523/?p=30', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2015-01-21 05:09:18', '2015-01-21 05:09:18', '<div class="row">\r\n<div class="col-lg-4 col-md-4 col-sm-4">\r\n<div class="block-wrap">\r\n\r\nWe are a well established, reliable and committed cleaning company that have been providing an exceptional and diligent service to our clients.\r\n\r\n</div>\r\n</div>\r\n</div>', 'Why Us?', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2015-01-21 05:09:18', '2015-01-21 05:09:18', '', 30, 'http://localhost/crossover/AU00523/?p=31', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2015-01-21 05:12:57', '2015-01-21 05:12:57', 'Our Vision is to be recognized as the leader in providing cleaning services in Australia, always generated confidence in our customers.', 'Our Vision', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2015-01-21 05:12:57', '2015-01-21 05:12:57', '', 28, 'http://localhost/crossover/AU00523/?p=32', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2015-01-21 05:15:52', '2015-01-21 05:15:52', 'Our Mission is to provide efficient cleaning services with the highest quality and responsibility to satisfy all needs of our clients.', 'Our Mission', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2015-01-21 05:15:52', '2015-01-21 05:15:52', '', 26, 'http://localhost/crossover/AU00523/?p=33', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2015-01-21 05:26:22', '2015-01-21 05:26:22', 'We are a well established, reliable and committed cleaning company that have been providing an exceptional and diligent service to our clients.', 'Why Us?', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2015-01-21 05:26:22', '2015-01-21 05:26:22', '', 30, 'http://localhost/crossover/AU00523/?p=34', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2015-01-21 05:31:08', '2015-01-21 05:31:08', 'Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.\r\n\r\nWe look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.\r\n\r\nWe look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 05:31:08', '2015-01-21 05:31:08', '', 7, 'http://localhost/crossover/AU00523/?p=35', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2015-01-21 05:31:29', '2015-01-21 05:31:29', '', 'welcome', '', 'inherit', 'open', 'open', '', 'welcome', '', '', '2015-01-21 05:31:29', '2015-01-21 05:31:29', '', 7, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/welcome.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2015-01-21 06:26:51', '2015-01-21 06:26:51', '<p>Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.</p><p>&nbsp;</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p>', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 06:26:51', '2015-01-21 06:26:51', '', 7, 'http://localhost/crossover/AU00523/?p=37', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2015-01-21 06:27:48', '2015-01-21 06:27:48', '<p>Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p>', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 06:27:48', '2015-01-21 06:27:48', '', 7, 'http://localhost/crossover/AU00523/?p=38', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2015-01-21 06:29:03', '2015-01-21 06:29:03', '<p>Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p>', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 06:29:03', '2015-01-21 06:29:03', '', 7, 'http://localhost/crossover/AU00523/?p=39', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2015-01-21 06:29:41', '2015-01-21 06:29:41', '<p>Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p>', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 06:29:41', '2015-01-21 06:29:41', '', 7, 'http://localhost/crossover/AU00523/?p=40', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2015-01-21 06:33:28', '2015-01-21 06:33:28', '<p>Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p>', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 06:33:28', '2015-01-21 06:33:28', '', 7, 'http://localhost/crossover/AU00523/?p=41', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2015-01-21 06:35:00', '2015-01-21 06:35:00', '<p>Sion Cleaning Services Pty. Ltd grants unique and high quality standard facilities by offering a wide variety of services. Our costumer satisfaction is paramount, therefore it is our aim to please and meet every single demand at our very best effort with a reasonable price.</p><p>We look forward to serving and convincing you that Sion Cleaning Services Pty. Ltd is truly the best when it comes to giving you a professional and friendly cleaning service.</p>', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-01-21 06:35:00', '2015-01-21 06:35:00', '', 7, 'http://localhost/crossover/AU00523/?p=42', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2015-01-21 06:40:00', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-01-21 06:40:00', '0000-00-00 00:00:00', '', 0, 'http://localhost/crossover/AU00523/?post_type=member&p=43', 0, 'member', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2015-01-21 06:43:57', '2015-01-21 06:43:57', '<p> Sion Cleaning Services adhere to the highest standards of residential cleaning in the Sydney metropolitan area. The satisfaction of our customers reflects this.</p><p>Our team of friendly and highly trained home cleaners will create and maintain your home to just the way you want it, clean, tidy and spotless. Imagine coming home after a long day of work and your home has been cleaned and it even smells fresh. All that worry about cleaning is gone and you can spend those precious extra hours with family and friends or relaxing in front of TV.</p><p>Our passion is creating clean homes for people who don\'t have time, don\'t have the physical capacity or can just appreciate the luxury of having extra time in their lives. We all have different needs, so we provide domestic cleaning services weekly, fortnightly, monthly or once-off.</p><p>Our team of friendly house cleaners are uniformed, fully insured, highly trained, and committed to giving you excellence in home cleaning. We all love our places to be welcoming and clean, and the team at Sion Cleaning Services pride themselves on attention to detail, reliability and caring for your most precious space, your home.</p>', 'Domestic Cleaning', '', 'publish', 'closed', 'closed', '', 'domestic-cleaning', '', '', '2015-01-21 06:45:51', '2015-01-21 06:45:51', '', 0, 'http://localhost/crossover/AU00523/?post_type=services&#038;p=44', 0, 'services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2015-01-21 06:45:44', '2015-01-21 06:45:44', '', 'domestic', '', 'inherit', 'open', 'open', '', 'domestic', '', '', '2015-01-21 06:45:44', '2015-01-21 06:45:44', '', 44, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/domestic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2015-01-21 06:48:06', '2015-01-21 06:48:06', '<p>Our team of Commercial cleaners at Sion Cleaning Services know the importance of having a clean work environment for your business. We take care of your commercial premises just as it were our own.<br /><br />You can expect friendly, uniformed, professional commercial cleaners to take care of your business environment, so you and your employees can work in clean and fresh surroundings.<br /><br />Our Commercial Cleaning services include Office Cleaning, Strata Cleaning, Medical Centres and Sports Centres in and around the Sydney metropolitan area.</p>', 'Commercial Cleaning.', '', 'publish', 'closed', 'closed', '', 'commercial-cleaning', '', '', '2015-01-21 06:48:06', '2015-01-21 06:48:06', '', 0, 'http://localhost/crossover/AU00523/?post_type=services&#038;p=46', 0, 'services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2015-01-21 06:48:01', '2015-01-21 06:48:01', '', 'commercial', '', 'inherit', 'open', 'open', '', 'commercial', '', '', '2015-01-21 06:48:01', '2015-01-21 06:48:01', '', 46, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/commercial.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2015-01-21 07:14:51', '2015-01-21 07:14:51', '<p>Many homeowners prefer carpet or area rugs in living rooms and children\'s playrooms, but carpeting is more of a challenge to keep clean than other floor surfaces. Beyond vacuuming regularly, you may also benefit from professional carpet cleaning or doing it yourself at least once a year.</p>', 'Carpet cleaning', '', 'publish', 'closed', 'closed', '', 'carpet-cleaning', '', '', '2015-01-21 07:14:52', '2015-01-21 07:14:52', '', 0, 'http://localhost/crossover/AU00523/?post_type=services&#038;p=48', 0, 'services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2015-01-21 07:04:09', '2015-01-21 07:04:09', '', 'carpet', '', 'inherit', 'open', 'open', '', 'carpet', '', '', '2015-01-21 07:04:09', '2015-01-21 07:04:09', '', 48, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/carpet.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2015-01-21 07:45:03', '2015-01-21 07:45:03', '<p>You can expect friendly, uniformed, professional commercial cleaners to take care of your business environment, so you and your employees can work in clean and fresh surroundings.</p>', 'Window Cleaning', '', 'publish', 'closed', 'closed', '', 'window-cleaning', '', '', '2015-01-21 07:45:03', '2015-01-21 07:45:03', '', 0, 'http://localhost/crossover/AU00523/?post_type=services&#038;p=50', 0, 'services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2015-01-21 07:44:54', '2015-01-21 07:44:54', '', 'window', '', 'inherit', 'open', 'open', '', 'window', '', '', '2015-01-21 07:44:54', '2015-01-21 07:44:54', '', 50, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/window.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2015-01-21 07:46:35', '2015-01-21 07:46:35', '<p>Our Commercial Cleaning services include Office Cleaning, Strata Cleaning, Medical Centres and Sports Centres in and around the Sydney metropolitan area.</p>', 'Spring Cleaning', '', 'publish', 'closed', 'closed', '', 'spring-cleaning', '', '', '2015-01-21 07:46:35', '2015-01-21 07:46:35', '', 0, 'http://localhost/crossover/AU00523/?post_type=services&#038;p=52', 0, 'services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2015-01-21 07:46:29', '2015-01-21 07:46:29', '', 'spring', '', 'inherit', 'open', 'open', '', 'spring', '', '', '2015-01-21 07:46:29', '2015-01-21 07:46:29', '', 52, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/spring.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2015-01-21 07:57:37', '2015-01-21 07:57:37', '<p>Our team of friendly house cleaners are uniformed, fully insured, highly trained, and committed to giving you excellence in home cleaning. We all love our places to be welcoming and clean, and the team at Sion Cleaning Services pride themselves on attention to detail, reliability and caring for your most precious space, your home.</p>', 'Water Pressure', '', 'publish', 'closed', 'closed', '', 'water-pressure', '', '', '2015-01-21 07:57:37', '2015-01-21 07:57:37', '', 0, 'http://localhost/crossover/AU00523/?post_type=services&#038;p=54', 0, 'services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2015-01-21 07:57:20', '2015-01-21 07:57:20', '', 'waterpressure', '', 'inherit', 'open', 'open', '', 'waterpressure', '', '', '2015-01-21 07:57:20', '2015-01-21 07:57:20', '', 54, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/waterpressure.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2015-01-21 08:35:43', '2015-01-21 08:35:43', '', 'Water pressure', '', 'publish', 'closed', 'closed', '', 'water-pressure', '', '', '2015-01-21 08:35:52', '2015-01-21 08:35:52', '', 0, 'http://localhost/crossover/AU00523/?post_type=featured_services&#038;p=56', 0, 'featured_services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2015-01-21 08:36:03', '2015-01-21 08:36:03', '', 'Window cleaning', '', 'publish', 'closed', 'closed', '', 'window-cleaning', '', '', '2015-01-21 08:36:10', '2015-01-21 08:36:10', '', 0, 'http://localhost/crossover/AU00523/?post_type=featured_services&#038;p=57', 0, 'featured_services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2015-01-21 08:36:21', '2015-01-21 08:36:21', '', 'Spring cleaning', '', 'publish', 'closed', 'closed', '', 'spring-cleaning', '', '', '2015-01-21 08:36:21', '2015-01-21 08:36:21', '', 0, 'http://localhost/crossover/AU00523/?post_type=featured_services&#038;p=58', 0, 'featured_services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2015-01-21 08:36:38', '2015-01-21 08:36:38', '', 'Spring cleaning', '', 'publish', 'closed', 'closed', '', 'spring-cleaning-2', '', '', '2015-01-21 08:36:38', '2015-01-21 08:36:38', '', 0, 'http://localhost/crossover/AU00523/?post_type=featured_services&#038;p=59', 0, 'featured_services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2015-01-21 08:36:53', '2015-01-21 08:36:53', '', 'Domestic cleaning', '', 'publish', 'closed', 'closed', '', 'domestic-cleaning', '', '', '2015-01-21 08:36:53', '2015-01-21 08:36:53', '', 0, 'http://localhost/crossover/AU00523/?post_type=featured_services&#038;p=60', 0, 'featured_services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2015-01-21 08:37:07', '2015-01-21 08:37:07', '', 'Office & commercial cleaning', '', 'publish', 'closed', 'closed', '', 'office-commercial-cleaning', '', '', '2015-01-21 08:37:07', '2015-01-21 08:37:07', '', 0, 'http://localhost/crossover/AU00523/?post_type=featured_services&#038;p=61', 0, 'featured_services', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2015-01-21 09:02:15', '2015-01-21 09:02:15', '[response]\r\n<ul> <li><label>Name:</label>  [text* your-name] </li>\r\n<li><label>Email:</label> [email* your-email] </li>\r\n<li><label>Phone:</label> [text* Phone] </li>\r\n<li><label>Message:</label> [textarea message 40x4]</li>\r\n <li><label>&nbsp;</label> [submit class:submit "Submit"]</li></ul>\n\n[your-name] <[your-email]>\nFrom: [your-name] <[your-email]>\r\n\r\nMessage Body:\r\nPhone:[Phone]\r\n[message]\nashokchand@crossovernepal.com\n\n\n\n\n[your-subject]\n[your-name] <[your-email]>\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on Sion Cleaning Services Pty Ltd (http://localhost/crossover/AU00523)\n[your-email]\n\n\n\nYour message was sent successfully. Thanks.\nFailed to send your message. Please try later or contact the administrator by another method.\nValidation errors occurred. Please confirm the fields and submit it again.\nFailed to send your message. Please try later or contact the administrator by another method.\nPlease accept the terms to proceed.\nPlease fill the required field.\nYour entered code is incorrect.\nNumber format seems invalid.\nThis number is too small.\nThis number is too large.\nEmail address seems invalid.\nURL seems invalid.\nTelephone number seems invalid.\nYour answer is not correct.\nDate format seems invalid.\nThis date is too early.\nThis date is too late.\nFailed to upload file.\nThis file type is not allowed.\nThis file is too large.\nFailed to upload file. Error occurred.', 'quote form', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2015-01-21 09:42:01', '2015-01-21 09:42:01', '', 0, 'http://localhost/crossover/AU00523/?post_type=wpcf7_contact_form&#038;p=62', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2015-01-22 02:15:56', '2015-01-22 02:15:56', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/waterpressure.jpg"><img class="alignnone size-medium wp-image-55" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/waterpressure-300x200.jpg" alt="waterpressure" width="300" height="200" /></a></p>', 'g1', '', 'publish', 'closed', 'closed', '', 'g1', '', '', '2015-01-22 02:15:56', '2015-01-22 02:15:56', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=63', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2015-01-22 02:45:06', '2015-01-22 02:45:06', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/spring.jpg"><img class="alignnone size-medium wp-image-53" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/spring-300x200.jpg" alt="spring" width="300" height="200" /></a></p>', 'g2', '', 'publish', 'closed', 'closed', '', 'g2', '', '', '2015-01-22 02:45:06', '2015-01-22 02:45:06', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=64', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2015-01-22 03:12:39', '2015-01-22 03:12:39', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/window.jpg"><img class="alignnone size-medium wp-image-51" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/window-300x200.jpg" alt="window" width="300" height="200" /></a></p>', 'g3', '', 'publish', 'closed', 'closed', '', 'g3', '', '', '2015-01-22 03:12:39', '2015-01-22 03:12:39', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=65', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2015-01-22 03:13:01', '2015-01-22 03:13:01', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/carpet.jpg"><img class="alignnone size-medium wp-image-49" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/carpet-300x200.jpg" alt="carpet" width="300" height="200" /></a></p>', 'g4', '', 'publish', 'closed', 'closed', '', 'g4', '', '', '2015-01-22 03:13:01', '2015-01-22 03:13:01', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=66', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2015-01-22 03:13:24', '2015-01-22 03:13:24', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/commercial.jpg"><img class="alignnone size-medium wp-image-47" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/commercial-300x200.jpg" alt="commercial" width="300" height="200" /></a></p>', 'g5', '', 'publish', 'closed', 'closed', '', 'g5', '', '', '2015-01-22 03:13:24', '2015-01-22 03:13:24', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=67', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2015-01-22 03:13:49', '2015-01-22 03:13:49', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/domestic.jpg"><img class="alignnone size-medium wp-image-45" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/domestic-300x200.jpg" alt="domestic" width="300" height="200" /></a></p>', 'g6', '', 'publish', 'closed', 'closed', '', 'g6', '', '', '2015-01-22 03:14:20', '2015-01-22 03:14:20', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=68', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2015-01-22 04:41:48', '2015-01-22 04:41:48', '[response]\r\n<table>\r\n<tr>\r\n<td class="l">Name (<span>*</span>)</td>\r\n<td class="r">[text* your-name]</td>\r\n</tr>\r\n<tr>\r\n<td class="l">Email (<span>*</span>)</td>\r\n   <td class="r"> [email* your-email] </td>\r\n</tr>\r\n<tr>\r\n<td class="l">Phone(<span>*</span>)</td>\r\n    <td class="r"> [tel* YourPhone]</td>\r\n</tr>\r\n<tr>\r\n<td class="l">Subject</td>\r\n   <td class="r"> [text your-subject] </td>\r\n</tr>\r\n<tr>\r\n<td class="l">Message</td>\r\n   <td class="r"> [textarea your-message] </td>\r\n</tr>\r\n<tr>\r\n<td class="l"></td>\r\n<td class="r">[submit "Send"]</td>\r\n</tr>\r\n</table>\n[your-subject]\n[your-name] <[your-email]>\nFrom: [your-name] <[your-email]>[YourPhone]\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\nashokchand@crossovernepal.com\n\n\n\n\n[your-subject]\n[your-name] <[your-email]>\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on Sion Cleaning Services Pty Ltd (http://localhost/crossover/AU00523)\n[your-email]\n\n\n\nYour message was sent successfully. Thanks.\nFailed to send your message. Please try later or contact the administrator by another method.\nValidation errors occurred. Please confirm the fields and submit it again.\nFailed to send your message. Please try later or contact the administrator by another method.\nPlease accept the terms to proceed.\nPlease fill the required field.\nYour entered code is incorrect.\nNumber format seems invalid.\nThis number is too small.\nThis number is too large.\nEmail address seems invalid.\nURL seems invalid.\nTelephone number seems invalid.\nYour answer is not correct.\nDate format seems invalid.\nThis date is too early.\nThis date is too late.\nFailed to upload file.\nThis file type is not allowed.\nThis file is too large.\nFailed to upload file. Error occurred.', 'Contact form', '', 'publish', 'open', 'open', '', 'contact-form', '', '', '2015-01-22 04:54:11', '2015-01-22 04:54:11', '', 0, 'http://localhost/crossover/AU00523/?post_type=wpcf7_contact_form&#038;p=69', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2015-01-22 07:50:57', '2015-01-22 07:50:57', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g4.jpg"><img class="alignnone size-medium wp-image-74" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g4-300x200.jpg" alt="g4" width="300" height="200" /></a></p>', 'g7', '', 'publish', 'closed', 'closed', '', 'g7', '', '', '2015-01-22 07:50:57', '2015-01-22 07:50:57', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=70', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2015-01-22 07:49:11', '2015-01-22 07:49:11', '', 'g1', '', 'inherit', 'open', 'open', '', 'g1-2', '', '', '2015-01-22 07:49:11', '2015-01-22 07:49:11', '', 70, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2015-01-22 07:49:13', '2015-01-22 07:49:13', '', 'g2', '', 'inherit', 'open', 'open', '', 'g2-2', '', '', '2015-01-22 07:49:13', '2015-01-22 07:49:13', '', 70, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2015-01-22 07:49:15', '2015-01-22 07:49:15', '', 'g3', '', 'inherit', 'open', 'open', '', 'g3-2', '', '', '2015-01-22 07:49:15', '2015-01-22 07:49:15', '', 70, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g3.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2015-01-22 07:49:16', '2015-01-22 07:49:16', '', 'g4', '', 'inherit', 'open', 'open', '', 'g4-2', '', '', '2015-01-22 07:49:16', '2015-01-22 07:49:16', '', 70, 'http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g4.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2015-01-22 07:51:20', '2015-01-22 07:51:20', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g3.jpg"><img class="alignnone size-medium wp-image-73" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g3-300x200.jpg" alt="g3" width="300" height="200" /></a></p>', 'g8', '', 'publish', 'closed', 'closed', '', 'g8', '', '', '2015-01-22 07:51:20', '2015-01-22 07:51:20', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=75', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2015-01-22 07:52:25', '2015-01-22 07:52:25', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g2.jpg"><img class="alignnone size-medium wp-image-72" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g2-300x200.jpg" alt="g2" width="300" height="200" /></a></p>', 'g9', '', 'publish', 'closed', 'closed', '', 'g9', '', '', '2015-01-22 07:52:25', '2015-01-22 07:52:25', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=76', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2015-01-22 07:52:44', '2015-01-22 07:52:44', '<p><a href="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g1.jpg"><img class="alignnone size-medium wp-image-71" src="http://localhost/crossover/AU00523/wp-content/uploads/2015/01/g1-300x200.jpg" alt="g1" width="300" height="200" /></a></p>', 'g10', '', 'publish', 'closed', 'closed', '', 'g10', '', '', '2015-01-22 07:52:44', '2015-01-22 07:52:44', '', 0, 'http://localhost/crossover/AU00523/?post_type=galleries&#038;p=77', 0, 'galleries', '', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2015-01-22 08:09:00', '2015-01-22 08:09:00', '<p>[hms_testimonials]</p>', 'Testimonials', '', 'publish', 'open', 'open', '', 'testimonials', '', '', '2015-01-22 08:11:09', '2015-01-22 08:11:09', '', 0, 'http://localhost/crossover/AU00523/?page_id=78', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2015-01-22 08:09:00', '2015-01-22 08:09:00', '<p>[hms_testimonials_rotating template="25" show_links="true" direction="DESC" ]</p>', 'Testimonials', '', 'inherit', 'open', 'open', '', '78-revision-v1', '', '', '2015-01-22 08:09:00', '2015-01-22 08:09:00', '', 78, 'http://localhost/crossover/AU00523/?p=79', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2015-01-22 08:09:46', '2015-01-22 08:09:46', ' ', '', '', 'publish', 'open', 'open', '', '80', '', '', '2015-01-22 08:09:46', '2015-01-22 08:09:46', '', 0, 'http://localhost/crossover/AU00523/?p=80', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2015-01-22 08:11:09', '2015-01-22 08:11:09', '<p>[hms_testimonials]</p>', 'Testimonials', '', 'inherit', 'open', 'open', '', '78-revision-v1', '', '', '2015-01-22 08:11:09', '2015-01-22 08:11:09', '', 78, 'http://localhost/crossover/AU00523/?p=81', 0, 'revision', '', 0) ;
#
# End of data contents of table `wp_posts`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_term_relationships`
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (9, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (10, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (80, 2, 0) ;
#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_term_taxonomy`
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'category', '', 0, 3) ;
#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_terms`
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Main Menu', 'main-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Success', 'success', 0) ;
#
# End of data contents of table `wp_terms`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_usermeta`
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'nickname', 'crossover') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'session_tokens', 'a:1:{s:64:"a1c551c1e866951f034a4182dee42a7717119b5142ba19315b66bf4dd8ebd83b";a:4:{s:10:"expiration";i:1422410116;s:2:"ip";s:3:"::1";s:2:"ua";s:72:"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:36.0) Gecko/20100101 Firefox/36.0";s:5:"login";i:1422237316;}}') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_dashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:8:"add-post";i:1;s:10:"add-banner";i:2;s:13:"add-galleries";i:3;s:10:"add-member";i:4;s:12:"add-post_tag";}') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'wp_user-settings-time', '1421818265') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'nav_menu_recently_edited', '2') ;
#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------

# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table `wp_users`
#
 
INSERT INTO `wp_users` VALUES (1, 'crossover', '$P$BZ0En4gF.UgqobaIMWlFKgjLtwI1TC/', 'crossover', 'ashokchand@crossovernepal.com', '', '2015-01-21 02:08:02', '', 0, 'crossover') ;
#
# End of data contents of table `wp_users`
# --------------------------------------------------------

